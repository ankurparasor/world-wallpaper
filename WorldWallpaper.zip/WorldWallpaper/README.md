# World Wallpaper (Android)

Downloads new landscape photos from around the world and sets them as your
phone wallpaper automatically, in the background, every 30 minutes (adjustable).

## Image sources (pick one in the app)
- **World landscapes**: a different recent landscape photo each interval, drawn from
  Bing's daily photos across 12 country editions (4K originals).
- **Photo of the day**: checks every interval and changes the wallpaper only when
  a new daily photo is published.
- **My own image link**: give it any direct image URL. The app changes the
  wallpaper whenever the image at that link changes (it compares file contents).

## Build the APK

### Option A: GitHub (no software to install)
1. Create a new GitHub repository and upload everything in this folder
   (including the hidden `.github` folder).
2. Open the **Actions** tab. The "Build APK" workflow runs on its own (or tap *Run workflow*).
3. When it finishes, open the run and download **WorldWallpaper-apk** (a zip with the `.apk` inside).

### Option B: Android Studio
1. Open this folder in Android Studio and let Gradle sync.
2. Use **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
3. The APK is in `app/build/outputs/apk/debug/`.

## Install on the Galaxy S23
1. Copy the `.apk` to the phone and tap it. Allow **Install unknown apps** for your
   file manager or browser when asked.
2. Open **World Wallpaper**, pick a source, then tap **Start auto-update**.
3. Tap **Allow running in background**, then choose **Allow**.
4. Samsung-specific (important): go to **Settings → Apps → World Wallpaper → Battery** and choose
   **Unrestricted**. Also check **Settings → Battery → Background usage limits** and make sure
   the app is not in *Sleeping* or *Deep sleeping apps*. Otherwise One UI may pause it.

## Notes
- Android limits background jobs to at least 15 minutes apart, and may delay a run a little
  when the phone is in deep idle.
- Each 4K photo is about 1–4 MB. If you use mobile data, checking every 30 minutes
  uses about 50–150 MB/day in *World landscapes* mode.
  *Photo of the day* only downloads once a day.
- Gallery saving keeps each photo once, so the same photo is never saved twice.
- If a Samsung lock-screen feature (Dynamic Lock Screen or a Good Lock theme) is turned on,
  it can override the lock-screen wallpaper. Turn it off if the lock screen doesn't change.
