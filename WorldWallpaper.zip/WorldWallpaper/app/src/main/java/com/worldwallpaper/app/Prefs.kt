package com.worldwallpaper.app

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    const val SOURCE = "source"
    const val SRC_DAILY = "daily"      // Bing photo of the day: changes only when a new one is published
    const val SRC_ROTATE = "rotate"    // a different world landscape every interval
    const val SRC_CUSTOM = "custom"    // any image URL the user enters

    const val CUSTOM_URL = "custom_url"
    const val INTERVAL_MIN = "interval_min"
    const val TARGET = "target"        // "both", "home", "lock"
    const val SAVE_TO_GALLERY = "save_to_gallery"
    const val AUTO_ON = "auto_on"

    const val SCREEN_W = "screen_w"
    const val SCREEN_H = "screen_h"

    const val LAST_ID = "last_id"
    const val LAST_TITLE = "last_title"
    const val LAST_TIME = "last_time"
    const val STATUS = "status"
    const val HISTORY = "history"
    const val SAVED_IDS = "saved_ids"

    fun get(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
}
