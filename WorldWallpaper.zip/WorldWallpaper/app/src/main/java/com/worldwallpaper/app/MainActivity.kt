package com.worldwallpaper.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.RadioGroup
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.text.DateFormat
import java.util.Date
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {

    private val intervals = listOf(15L, 30L, 60L, 120L, 360L, 720L)
    private val intervalLabels = listOf(
        "Every 15 min", "Every 30 min", "Every hour", "Every 2 hours", "Every 6 hours", "Every 12 hours"
    )

    private lateinit var prefs: SharedPreferences
    private lateinit var preview: ImageView
    private lateinit var statusText: TextView
    private lateinit var titleText: TextView
    private lateinit var sourceGroup: RadioGroup
    private lateinit var urlInput: EditText
    private lateinit var intervalSpinner: Spinner
    private lateinit var targetGroup: RadioGroup
    private lateinit var saveBox: CheckBox
    private lateinit var batteryButton: Button

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs.get(this)
        storeScreenSize()

        preview = findViewById(R.id.preview)
        statusText = findViewById(R.id.status)
        titleText = findViewById(R.id.imageTitle)
        sourceGroup = findViewById(R.id.sourceGroup)
        urlInput = findViewById(R.id.customUrl)
        intervalSpinner = findViewById(R.id.interval)
        targetGroup = findViewById(R.id.targetGroup)
        saveBox = findViewById(R.id.saveToGallery)
        batteryButton = findViewById(R.id.btnBattery)

        intervalSpinner.adapter =
            ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, intervalLabels)

        loadSettings()
        sourceGroup.setOnCheckedChangeListener { _, id ->
            urlInput.visibility = if (id == R.id.srcCustom) View.VISIBLE else View.GONE
        }

        findViewById<Button>(R.id.btnStart).setOnClickListener {
            if (!saveSettings()) return@setOnClickListener
            prefs.edit().putBoolean(Prefs.AUTO_ON, true).apply()
            Scheduler.start(this, intervals[intervalSpinner.selectedItemPosition])
            Scheduler.runNow(this)
            toast("Auto-update started")
        }
        findViewById<Button>(R.id.btnStop).setOnClickListener {
            prefs.edit().putBoolean(Prefs.AUTO_ON, false)
                .putString(Prefs.STATUS, "Auto-update stopped").apply()
            Scheduler.stop(this)
        }
        findViewById<Button>(R.id.btnNow).setOnClickListener {
            if (!saveSettings()) return@setOnClickListener
            if (prefs.getBoolean(Prefs.AUTO_ON, false)) {
                Scheduler.start(this, intervals[intervalSpinner.selectedItemPosition])
            }
            Scheduler.runNow(this)
            toast("Fetching a new wallpaper…")
        }
        batteryButton.setOnClickListener { askUnrestrictedBattery() }
    }

    override fun onResume() {
        super.onResume()
        prefs.registerOnSharedPreferenceChangeListener(listener)
        refresh()
    }

    override fun onPause() {
        prefs.unregisterOnSharedPreferenceChangeListener(listener)
        super.onPause()
    }

    private fun loadSettings() {
        sourceGroup.check(
            when (prefs.getString(Prefs.SOURCE, Prefs.SRC_ROTATE)) {
                Prefs.SRC_DAILY -> R.id.srcDaily
                Prefs.SRC_CUSTOM -> R.id.srcCustom
                else -> R.id.srcRotate
            }
        )
        urlInput.setText(prefs.getString(Prefs.CUSTOM_URL, ""))
        urlInput.visibility =
            if (sourceGroup.checkedRadioButtonId == R.id.srcCustom) View.VISIBLE else View.GONE
        intervalSpinner.setSelection(
            intervals.indexOf(prefs.getLong(Prefs.INTERVAL_MIN, 30L)).coerceAtLeast(0)
        )
        targetGroup.check(
            when (prefs.getString(Prefs.TARGET, "both")) {
                "home" -> R.id.targetHome
                "lock" -> R.id.targetLock
                else -> R.id.targetBoth
            }
        )
        saveBox.isChecked = prefs.getBoolean(Prefs.SAVE_TO_GALLERY, true)
    }

    private fun saveSettings(): Boolean {
        val source = when (sourceGroup.checkedRadioButtonId) {
            R.id.srcDaily -> Prefs.SRC_DAILY
            R.id.srcCustom -> Prefs.SRC_CUSTOM
            else -> Prefs.SRC_ROTATE
        }
        val url = urlInput.text.toString().trim()
        if (source == Prefs.SRC_CUSTOM && !url.startsWith("http")) {
            toast("Enter a direct image link starting with http(s)://")
            return false
        }
        val oldSource = prefs.getString(Prefs.SOURCE, null)
        prefs.edit()
            .putString(Prefs.SOURCE, source)
            .putString(Prefs.CUSTOM_URL, url)
            .putLong(Prefs.INTERVAL_MIN, intervals[intervalSpinner.selectedItemPosition])
            .putString(
                Prefs.TARGET, when (targetGroup.checkedRadioButtonId) {
                    R.id.targetHome -> "home"
                    R.id.targetLock -> "lock"
                    else -> "both"
                }
            )
            .putBoolean(Prefs.SAVE_TO_GALLERY, saveBox.isChecked)
            .apply { if (oldSource != source) remove(Prefs.LAST_ID) }
            .apply()
        return true
    }

    private fun refresh() {
        val auto = prefs.getBoolean(Prefs.AUTO_ON, false)
        val minutes = prefs.getLong(Prefs.INTERVAL_MIN, 30L)
        val state = if (auto) "● Running — checks every ${label(minutes)}" else "○ Auto-update is off"
        val status = prefs.getString(Prefs.STATUS, "Tap \"Start auto-update\" to begin")
        statusText.text = "$state\n$status"

        val title = prefs.getString(Prefs.LAST_TITLE, null)
        val time = prefs.getLong(Prefs.LAST_TIME, 0L)
        titleText.text = if (title != null && time > 0) {
            "$title\nSet ${DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(time))}"
        } else "No wallpaper set yet"

        val file = File(filesDir, WallpaperWorker.PREVIEW_FILE)
        if (file.exists()) {
            val opts = BitmapFactory.Options().apply { inSampleSize = 4 }
            preview.setImageBitmap(BitmapFactory.decodeFile(file.absolutePath, opts))
        }

        val pm = getSystemService(PowerManager::class.java)
        batteryButton.visibility =
            if (pm.isIgnoringBatteryOptimizations(packageName)) View.GONE else View.VISIBLE
    }

    private fun label(m: Long) = if (m < 60) "$m min" else if (m == 60L) "hour" else "${m / 60} hours"

    @SuppressLint("BatteryLife")
    private fun askUnrestrictedBattery() {
        try {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    .setData(Uri.parse("package:$packageName"))
            )
        }
    }

    /** Real full-screen size (incl. status/nav bars) so the crop fills the screen exactly. */
    @Suppress("DEPRECATION")
    private fun storeScreenSize() {
        val (w, h) = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = windowManager.maximumWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val dm = DisplayMetrics().also { windowManager.defaultDisplay.getRealMetrics(it) }
            dm.widthPixels to dm.heightPixels
        }
        prefs.edit()
            .putInt(Prefs.SCREEN_W, min(w, h))
            .putInt(Prefs.SCREEN_H, max(w, h))
            .apply()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
