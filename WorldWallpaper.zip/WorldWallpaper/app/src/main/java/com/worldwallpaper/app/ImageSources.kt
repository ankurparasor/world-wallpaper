package com.worldwallpaper.app

import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import kotlin.random.Random

data class RemoteImage(val url: String, val title: String, val id: String)

object Http {
    private fun open(url: String): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 60_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "WorldWallpaper/1.0 (Android)")
        }

    fun getBytes(url: String): ByteArray {
        val c = open(url)
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode} for $url")
            return c.inputStream.use { it.readBytes() }
        } finally {
            c.disconnect()
        }
    }

    fun getText(url: String): String = String(getBytes(url), Charsets.UTF_8)
}

/**
 * Bing publishes a new landscape photo every day, and each country edition
 * often has a different one. The archive endpoint returns up to 8 recent days.
 */
object ImageSources {
    private val markets = listOf(
        "en-IN", "en-US", "en-GB", "en-CA", "en-AU", "ja-JP",
        "de-DE", "fr-FR", "es-ES", "it-IT", "pt-BR", "zh-CN"
    )

    /** Today's photo. Checked every interval; only applied when it changes. */
    fun bingDaily(): RemoteImage = bing("en-IN", 0)

    /** A random recent landscape from any edition, avoiding recently shown ones. */
    fun randomLandscape(recent: Set<String>): RemoteImage {
        var img = bing(markets.random(), Random.nextInt(0, 8))
        repeat(8) {
            if (img.id !in recent) return img
            img = bing(markets.random(), Random.nextInt(0, 8))
        }
        return img
    }

    private fun bing(market: String, daysAgo: Int): RemoteImage {
        val json = Http.getText(
            "https://www.bing.com/HPImageArchive.aspx?format=js&idx=$daysAgo&n=1&mkt=$market"
        )
        val o = JSONObject(json).getJSONArray("images").getJSONObject(0)
        val base = o.getString("urlbase")              // e.g. /th?id=OHR.LakeTekapo_EN-IN1234
        // Same photo has a different suffix per country, so dedupe on the name only.
        val id = base.substringAfter("OHR.").substringBefore("_")
        val title = o.optString("copyright").ifBlank { o.optString("title") }
        return RemoteImage("https://www.bing.com${base}_UHD.jpg", title, id)
    }
}
