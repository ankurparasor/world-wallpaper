package com.worldwallpaper.app

import android.app.WallpaperManager
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.provider.MediaStore
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.min

object Scheduler {
    private const val PERIODIC = "wallpaper_periodic"
    private const val NOW = "wallpaper_now"

    private val network = Constraints.Builder()
        .setRequiredNetworkType(NetworkType.CONNECTED)
        .build()

    fun start(ctx: Context, minutes: Long) {
        val req = PeriodicWorkRequestBuilder<WallpaperWorker>(max(15L, minutes), TimeUnit.MINUTES)
            .setConstraints(network)
            .build()
        WorkManager.getInstance(ctx)
            .enqueueUniquePeriodicWork(PERIODIC, ExistingPeriodicWorkPolicy.UPDATE, req)
    }

    fun stop(ctx: Context) = WorkManager.getInstance(ctx).cancelUniqueWork(PERIODIC)

    fun runNow(ctx: Context) {
        val req = OneTimeWorkRequestBuilder<WallpaperWorker>()
            .setInputData(workDataOf(WallpaperWorker.KEY_FORCE to true))
            .setConstraints(network)
            .build()
        WorkManager.getInstance(ctx).enqueueUniqueWork(NOW, ExistingWorkPolicy.REPLACE, req)
    }
}

class WallpaperWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    companion object {
        const val KEY_FORCE = "force"
        const val PREVIEW_FILE = "current.jpg"
    }

    private val prefs = Prefs.get(ctx)

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val force = inputData.getBoolean(KEY_FORCE, false)
        try {
            status("Checking for a new image…")
            val picked = pickImage(force)
            if (picked == null) {
                status("No new image yet — checked ${now()}")
                return@withContext Result.success()
            }
            val (bytes, id, title) = picked

            val bitmap = cropToScreen(bytes)
            setWallpaper(bitmap)
            File(applicationContext.filesDir, PREVIEW_FILE).outputStream().use {
                bitmap.compress(Bitmap.CompressFormat.JPEG, 85, it)
            }
            if (prefs.getBoolean(Prefs.SAVE_TO_GALLERY, true)) saveToGallery(bytes, id)

            val history = (prefs.getStringSet(Prefs.HISTORY, emptySet()) ?: emptySet())
                .toMutableList().apply { add(id) }.takeLast(40).toSet()
            prefs.edit()
                .putString(Prefs.LAST_ID, id)
                .putString(Prefs.LAST_TITLE, title)
                .putLong(Prefs.LAST_TIME, System.currentTimeMillis())
                .putStringSet(Prefs.HISTORY, history)
                .putString(Prefs.STATUS, "Wallpaper updated ${now()}")
                .apply()
            Result.success()
        } catch (e: Exception) {
            if (runAttemptCount < 3) {
                status("Failed (${e.message ?: e.javaClass.simpleName}) — retrying")
                Result.retry()
            } else {
                status("Failed (${e.message ?: e.javaClass.simpleName}) — will try next interval")
                Result.success()
            }
        }
    }

    /** Returns image bytes + id + title, or null if nothing changed. */
    private fun pickImage(force: Boolean): Triple<ByteArray, String, String>? {
        val lastId = prefs.getString(Prefs.LAST_ID, null)
        return when (prefs.getString(Prefs.SOURCE, Prefs.SRC_ROTATE)) {
            Prefs.SRC_DAILY -> {
                val img = ImageSources.bingDaily()
                if (!force && img.id == lastId) null
                else Triple(Http.getBytes(img.url), img.id, img.title)
            }
            Prefs.SRC_CUSTOM -> {
                val url = prefs.getString(Prefs.CUSTOM_URL, "").orEmpty().trim()
                if (url.isEmpty()) throw IOException("No custom URL set")
                val bytes = Http.getBytes(url)
                val hash = sha1(bytes)
                if (!force && hash == lastId) null
                else Triple(bytes, hash, url.substringAfterLast('/'))
            }
            else -> {
                val recent = prefs.getStringSet(Prefs.HISTORY, emptySet()) ?: emptySet()
                val img = ImageSources.randomLandscape(recent + listOfNotNull(lastId))
                Triple(Http.getBytes(img.url), img.id, img.title)
            }
        }
    }

    /** Decode efficiently and centre-crop to the phone's portrait screen size. */
    private fun cropToScreen(bytes: ByteArray): Bitmap {
        val dm = applicationContext.resources.displayMetrics
        val tw = prefs.getInt(Prefs.SCREEN_W, min(dm.widthPixels, dm.heightPixels))
        val th = prefs.getInt(Prefs.SCREEN_H, max(dm.widthPixels, dm.heightPixels))

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0) throw IOException("Downloaded file is not an image")
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= tw && bounds.outHeight / (sample * 2) >= th) sample *= 2

        val src = BitmapFactory.decodeByteArray(
            bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample }
        ) ?: throw IOException("Could not decode image")

        val scale = max(tw / src.width.toFloat(), th / src.height.toFloat())
        val cw = min(src.width, (tw / scale).toInt())
        val ch = min(src.height, (th / scale).toInt())
        val cropped = Bitmap.createBitmap(src, (src.width - cw) / 2, (src.height - ch) / 2, cw, ch)
        return Bitmap.createScaledBitmap(cropped, tw, th, true)
    }

    private fun setWallpaper(bitmap: Bitmap) {
        val flags = when (prefs.getString(Prefs.TARGET, "both")) {
            "home" -> WallpaperManager.FLAG_SYSTEM
            "lock" -> WallpaperManager.FLAG_LOCK
            else -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
        }
        WallpaperManager.getInstance(applicationContext).setBitmap(bitmap, null, true, flags)
    }

    /** Keeps the full-resolution original in Gallery → Pictures/World Wallpapers (once per image). */
    private fun saveToGallery(bytes: ByteArray, id: String) {
        val saved = prefs.getStringSet(Prefs.SAVED_IDS, emptySet()) ?: emptySet()
        if (id in saved) return
        val safeName = id.replace(Regex("[^A-Za-z0-9_-]"), "").take(60).ifEmpty { "image" }
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "$safeName.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/World Wallpapers")
        }
        val resolver = applicationContext.contentResolver
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return
        resolver.openOutputStream(uri)?.use { it.write(bytes) }
        prefs.edit().putStringSet(Prefs.SAVED_IDS, saved + id).apply()
    }

    private fun status(msg: String) = prefs.edit().putString(Prefs.STATUS, msg).apply()

    private fun now() = SimpleDateFormat("d MMM, h:mm a", Locale.getDefault()).format(Date())

    private fun sha1(b: ByteArray) =
        MessageDigest.getInstance("SHA-1").digest(b).joinToString("") { "%02x".format(it) }
}
