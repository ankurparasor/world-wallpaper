plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.worldwallpaper.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.worldwallpaper.app"
        minSdk = 29
        targetSdk = 35
        versionCode = 2
        versionName = "2.0"
    }

    // A fixed key, so each new build installs as an update over the previous one.
    signingConfigs {
        create("release") {
            storeFile = file("release.keystore")
            storePassword = "ww-release-2026"
            keyAlias = "worldwallpaper"
            keyPassword = "ww-release-2026"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            isDebuggable = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("release")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation("androidx.work:work-runtime-ktx:2.9.1")
}
