package com.worldwallpaper.app

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.format.DateUtils
import android.util.DisplayMetrics
import android.util.TypedValue
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {

    private val intervals = listOf(15L, 30L, 60L, 120L, 360L, 720L)
    private val intervalLabels = listOf("15 min", "30 min", "1 hour", "2 hours", "6 hours", "12 hours")

    private lateinit var prefs: SharedPreferences
    private lateinit var heroImage: ImageView
    private lateinit var heroTitle: TextView
    private lateinit var heroPlace: TextView
    private lateinit var heroMeta: TextView
    private lateinit var heroKicker: TextView
    private lateinit var statusDot: View
    private lateinit var statusPillText: TextView
    private lateinit var statusLine: TextView
    private lateinit var btnNow: TextView
    private lateinit var switchAuto: Switch
    private lateinit var switchSave: Switch
    private lateinit var chipRow: LinearLayout
    private lateinit var customBox: View
    private lateinit var customUrl: EditText
    private lateinit var batterySub: TextView
    private lateinit var batteryChevron: View

    private val chips = mutableListOf<TextView>()
    private var shownPreviewTime = -1L
    private var pulse: ObjectAnimator? = null
    private var suppressSwitch = false

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> refresh() }

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Draw behind the status and navigation bars for a full-bleed photo.
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        setContentView(R.layout.activity_main)

        prefs = Prefs.get(this)
        storeScreenSize()
        bindViews()
        applyInsets()
        buildChips()
        wireControls()

        pulse = ObjectAnimator.ofFloat(statusDot, View.ALPHA, 1f, 0.25f).apply {
            duration = 900
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
        }
    }

    override fun onResume() {
        super.onResume()
        prefs.registerOnSharedPreferenceChangeListener(listener)
        refresh()
    }

    override fun onPause() {
        prefs.unregisterOnSharedPreferenceChangeListener(listener)
        pulse?.pause()
        super.onPause()
    }

    // ---------- setup ----------

    private fun bindViews() {
        heroImage = findViewById(R.id.heroImage)
        heroTitle = findViewById(R.id.heroTitle)
        heroPlace = findViewById(R.id.heroPlace)
        heroMeta = findViewById(R.id.heroMeta)
        heroKicker = findViewById(R.id.heroKicker)
        statusDot = findViewById(R.id.statusDot)
        statusPillText = findViewById(R.id.statusPillText)
        statusLine = findViewById(R.id.statusLine)
        btnNow = findViewById(R.id.btnNow)
        switchAuto = findViewById(R.id.switchAuto)
        switchSave = findViewById(R.id.switchSave)
        chipRow = findViewById(R.id.chipRow)
        customBox = findViewById(R.id.customBox)
        customUrl = findViewById(R.id.customUrl)
        batterySub = findViewById(R.id.batterySub)
        batteryChevron = findViewById(R.id.batteryChevron)
    }

    @Suppress("DEPRECATION")
    private fun applyInsets() {
        val topBar = findViewById<View>(R.id.topBar)
        val content = findViewById<View>(R.id.content)
        findViewById<View>(R.id.root).setOnApplyWindowInsetsListener { _, insets ->
            topBar.setPadding(
                topBar.paddingLeft, insets.systemWindowInsetTop + dp(12),
                topBar.paddingRight, topBar.paddingBottom
            )
            content.setPadding(0, 0, 0, insets.systemWindowInsetBottom)
            insets
        }
    }

    private fun buildChips() {
        intervalLabels.forEachIndexed { i, label ->
            val chip = TextView(this).apply {
                text = label
                textSize = 14f
                setTextColor(resources.getColorStateList(R.color.chip_text, theme))
                background = getDrawable(R.drawable.bg_chip)
                setPadding(dp(18), dp(10), dp(18), dp(10))
                isClickable = true
                setOnClickListener {
                    prefs.edit().putLong(Prefs.INTERVAL_MIN, intervals[i]).apply()
                    if (prefs.getBoolean(Prefs.AUTO_ON, false)) Scheduler.start(context, intervals[i])
                    tapFeedback(this)
                }
            }
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { marginEnd = dp(8) }
            chipRow.addView(chip, lp)
            chips += chip
        }
    }

    private fun wireControls() {
        btnNow.setOnClickListener {
            tapFeedback(btnNow)
            Scheduler.runNow(this)
        }

        switchAuto.setOnCheckedChangeListener { _, on ->
            if (suppressSwitch) return@setOnCheckedChangeListener
            prefs.edit().putBoolean(Prefs.AUTO_ON, on).apply()
            if (on) {
                Scheduler.start(this, prefs.getLong(Prefs.INTERVAL_MIN, 30L))
                if (prefs.getLong(Prefs.LAST_TIME, 0L) == 0L) Scheduler.runNow(this)
                toast("Auto-update is on")
            } else {
                Scheduler.stop(this)
                toast("Auto-update paused")
            }
        }

        switchSave.setOnCheckedChangeListener { _, on ->
            if (!suppressSwitch) prefs.edit().putBoolean(Prefs.SAVE_TO_GALLERY, on).apply()
        }

        findViewById<View>(R.id.optRotate).setOnClickListener { chooseSource(Prefs.SRC_ROTATE, it) }
        findViewById<View>(R.id.optDaily).setOnClickListener { chooseSource(Prefs.SRC_DAILY, it) }
        findViewById<View>(R.id.optCustom).setOnClickListener {
            tapFeedback(it)
            customBox.visibility = View.VISIBLE
            customUrl.requestFocus()
            if (prefs.getString(Prefs.SOURCE, null) != Prefs.SRC_CUSTOM &&
                Http.isAllowedUrl(prefs.getString(Prefs.CUSTOM_URL, "").orEmpty())
            ) chooseSource(Prefs.SRC_CUSTOM, null)
        }
        customUrl.setText(prefs.getString(Prefs.CUSTOM_URL, ""))
        findViewById<View>(R.id.btnUseLink).setOnClickListener { useCustomLink() }
        customUrl.setOnEditorActionListener { _, action, _ ->
            if (action == EditorInfo.IME_ACTION_DONE) { useCustomLink(); true } else false
        }

        val segments = mapOf(R.id.segBoth to "both", R.id.segHome to "home", R.id.segLock to "lock")
        segments.forEach { (id, value) ->
            findViewById<View>(id).setOnClickListener {
                prefs.edit().putString(Prefs.TARGET, value).apply()
                tapFeedback(it)
                toast("Applies from the next wallpaper")
            }
        }

        findViewById<View>(R.id.rowWidget).setOnClickListener { pinWidget() }
        findViewById<View>(R.id.rowBattery).setOnClickListener { askUnrestrictedBattery() }
    }

    // ---------- actions ----------

    private fun chooseSource(source: String, view: View?) {
        view?.let { tapFeedback(it) }
        if (source != Prefs.SRC_CUSTOM) customBox.visibility = View.GONE
        val changed = prefs.getString(Prefs.SOURCE, Prefs.SRC_ROTATE) != source
        prefs.edit().putString(Prefs.SOURCE, source).apply()
        if (changed) Scheduler.runNow(this)
    }

    private fun useCustomLink() {
        val url = customUrl.text.toString().trim()
        if (!Http.isAllowedUrl(url)) {
            toast("Use a secure link starting with https://")
            return
        }
        getSystemService(InputMethodManager::class.java)
            ?.hideSoftInputFromWindow(customUrl.windowToken, 0)
        customUrl.clearFocus()
        prefs.edit().putString(Prefs.CUSTOM_URL, url).putString(Prefs.SOURCE, Prefs.SRC_CUSTOM)
            .remove(Prefs.LAST_ID).apply()
        Scheduler.runNow(this)
    }

    private fun pinWidget() {
        val manager = getSystemService(AppWidgetManager::class.java)
        if (manager != null && manager.isRequestPinAppWidgetSupported) {
            manager.requestPinAppWidget(ComponentName(this, WallpaperWidget::class.java), null, null)
        } else {
            toast("Long-press your home screen → Widgets → World Wallpaper")
        }
    }

    @SuppressLint("BatteryLife")
    private fun askUnrestrictedBattery() {
        val intent = if (batteryAllowed()) {
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
        } else {
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
        }.setData(Uri.parse("package:$packageName"))
        try {
            startActivity(intent)
        } catch (e: Exception) {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    .setData(Uri.parse("package:$packageName"))
            )
        }
    }

    // ---------- UI state ----------

    private fun refresh() {
        val auto = prefs.getBoolean(Prefs.AUTO_ON, false)
        val busy = Prefs.isBusy(prefs)
        val interval = prefs.getLong(Prefs.INTERVAL_MIN, 30L)
        val source = prefs.getString(Prefs.SOURCE, Prefs.SRC_ROTATE)
        val target = prefs.getString(Prefs.TARGET, "both")

        // Status pill
        val (pillText, dotColor) = when {
            busy -> "Updating" to getColor(R.color.warn)
            auto -> "Live" to getColor(R.color.live)
            else -> "Paused" to getColor(R.color.text_faint)
        }
        statusPillText.text = pillText
        statusDot.backgroundTintList = ColorStateList.valueOf(dotColor)
        if (busy || auto) {
            if (pulse?.isStarted == true) pulse?.resume() else pulse?.start()
        } else {
            pulse?.cancel(); statusDot.alpha = 1f
        }

        // Main button
        // Stays tappable while busy, so a stalled download (e.g. no signal) can be retried.
        btnNow.alpha = if (busy) 0.75f else 1f
        btnNow.text = if (busy) "Finding a beautiful place…" else "✨  New wallpaper"

        // Hero
        val time = prefs.getLong(Prefs.LAST_TIME, 0L)
        if (time > 0) {
            heroKicker.text = "ON YOUR SCREEN NOW"
            heroTitle.text = prefs.getString(Prefs.LAST_TITLE, "")
            val place = prefs.getString(Prefs.LAST_PLACE, "").orEmpty()
            heroPlace.text = if (place.isNotBlank()) "📍 $place" else ""
            heroPlace.visibility = if (place.isBlank()) View.GONE else View.VISIBLE
            val credit = prefs.getString(Prefs.LAST_CREDIT, "").orEmpty()
            val ago = DateUtils.getRelativeTimeSpanString(
                time, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS
            )
            heroMeta.text = listOf(credit, "Set $ago").filter { it.isNotBlank() }.joinToString("  ·  ")
            if (time != shownPreviewTime) loadPreview(time)
        }

        // Status line under the button
        val status = prefs.getString(Prefs.STATUS, null)
        statusLine.text = when {
            busy -> "Downloading in 4K and fitting it to your screen"
            auto -> "Next change in about ${intervalText(interval)}" +
                (status?.let { "  ·  $it" } ?: "")
            else -> status ?: "Turn on auto-update to change it every ${intervalText(interval)}"
        }

        // Controls
        suppressSwitch = true
        switchAuto.isChecked = auto
        switchSave.isChecked = prefs.getBoolean(Prefs.SAVE_TO_GALLERY, true)
        suppressSwitch = false

        chips.forEachIndexed { i, c -> c.isSelected = intervals[i] == interval }

        setSelected(R.id.optRotate, R.id.checkRotate, source == Prefs.SRC_ROTATE)
        setSelected(R.id.optDaily, R.id.checkDaily, source == Prefs.SRC_DAILY)
        setSelected(R.id.optCustom, R.id.checkCustom, source == Prefs.SRC_CUSTOM)
        if (source == Prefs.SRC_CUSTOM) customBox.visibility = View.VISIBLE

        findViewById<View>(R.id.segBoth).isSelected = target == "both"
        findViewById<View>(R.id.segHome).isSelected = target == "home"
        findViewById<View>(R.id.segLock).isSelected = target == "lock"

        val allowed = batteryAllowed()
        batterySub.text = if (allowed) "Allowed ✓  Also set Battery → Unrestricted" else "Tap to allow, so updates aren't paused"
        batterySub.setTextColor(getColor(if (allowed) R.color.live else R.color.warn))
    }

    private fun setSelected(cardId: Int, checkId: Int, selected: Boolean) {
        findViewById<View>(cardId).isSelected = selected
        findViewById<View>(checkId).visibility = if (selected) View.VISIBLE else View.INVISIBLE
    }

    private fun loadPreview(time: Long) {
        val file = File(filesDir, WallpaperWorker.PREVIEW_FILE)
        if (!file.exists()) return
        val bmp = BitmapFactory.decodeFile(
            file.absolutePath, BitmapFactory.Options().apply { inSampleSize = 2 }
        ) ?: return
        val firstLoad = shownPreviewTime == -1L
        shownPreviewTime = time
        heroImage.setImageBitmap(bmp)
        if (!firstLoad) {
            heroImage.alpha = 0f
            heroImage.scaleX = 1.08f; heroImage.scaleY = 1.08f
            heroImage.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(900).start()
        }
    }

    // ---------- helpers ----------

    private fun tapFeedback(v: View) {
        v.performHapticFeedback(android.view.HapticFeedbackConstants.CONTEXT_CLICK)
        v.animate().scaleX(0.96f).scaleY(0.96f).setDuration(80).withEndAction {
            v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
        }.start()
    }

    private fun batteryAllowed() =
        getSystemService(PowerManager::class.java)?.isIgnoringBatteryOptimizations(packageName) == true

    private fun intervalText(m: Long) = intervalLabels[intervals.indexOf(m).coerceAtLeast(0)]

    private fun dp(v: Int) = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
    ).toInt()

    /** Real full-screen size (incl. status/nav bars) so the crop fills the screen exactly. */
    @Suppress("DEPRECATION")
    private fun storeScreenSize() {
        val (w, h) = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = windowManager.maximumWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val dm = DisplayMetrics().also { windowManager.defaultDisplay.getRealMetrics(it) }
            dm.widthPixels to dm.heightPixels
        }
        prefs.edit().putInt(Prefs.SCREEN_W, min(w, h)).putInt(Prefs.SCREEN_H, max(w, h)).apply()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
