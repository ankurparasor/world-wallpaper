package com.worldwallpaper.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.text.format.DateUtils
import android.widget.RemoteViews

/** See-through home-screen widget showing what the current wallpaper is. */
class WallpaperWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, manager: AppWidgetManager, ids: IntArray) {
        val views = build(ctx)
        ids.forEach { manager.updateAppWidget(it, views) }
    }

    companion object {
        fun updateAll(ctx: Context) {
            val manager = AppWidgetManager.getInstance(ctx) ?: return
            val ids = manager.getAppWidgetIds(ComponentName(ctx, WallpaperWidget::class.java))
            if (ids.isEmpty()) return
            val views = build(ctx)
            ids.forEach { manager.updateAppWidget(it, views) }
        }

        private fun build(ctx: Context): RemoteViews {
            val p = Prefs.get(ctx)
            val v = RemoteViews(ctx.packageName, R.layout.widget_wallpaper)

            val title = p.getString(Prefs.LAST_TITLE, null)
            val place = p.getString(Prefs.LAST_PLACE, null)
            val credit = p.getString(Prefs.LAST_CREDIT, "").orEmpty()
            val time = p.getLong(Prefs.LAST_TIME, 0L)

            v.setTextViewText(R.id.wTitle, title ?: "World Wallpaper")
            v.setTextViewText(R.id.wPlace, place?.ifBlank { null } ?: "Tap ↻ for your first photo")
            val meta = when {
                Prefs.isBusy(p) -> "Finding a new photo…"
                time > 0 -> {
                    val ago = DateUtils.getRelativeTimeSpanString(
                        time, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS
                    )
                    if (credit.isNotBlank()) "$credit · $ago" else "Updated $ago"
                }
                else -> ""
            }
            v.setTextViewText(R.id.wMeta, meta)

            val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            val open = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP), flags
            )
            val refresh = PendingIntent.getBroadcast(
                ctx, 1, Intent(ctx, RefreshReceiver::class.java), flags
            )
            v.setOnClickPendingIntent(R.id.widgetRoot, open)
            v.setOnClickPendingIntent(R.id.wRefresh, refresh)
            return v
        }
    }
}

/** Handles the widget's ↻ button. Not exported, so only this app's widget can trigger it. */
class RefreshReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Scheduler.runNow(ctx)
    }
}
