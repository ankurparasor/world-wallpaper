package com.worldwallpaper.app

import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

data class RemoteImage(
    val url: String,
    val id: String,
    val title: String,   // e.g. "Autumn in the Dolomites"
    val place: String,   // e.g. "Seceda peak, Dolomites, Italy"
    val credit: String   // e.g. "© Photographer/Getty Images"
)

object Http {
    private const val MAX_BYTES = 25 * 1024 * 1024 // refuse anything over 25 MB

    fun isAllowedUrl(url: String): Boolean =
        url.startsWith("https://", ignoreCase = true) && url.length < 2048

    fun getBytes(url: String): ByteArray {
        if (!isAllowedUrl(url)) throw IOException("Only https:// links are allowed")
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 60_000
            instanceFollowRedirects = true // Android never follows https → http redirects
            setRequestProperty("User-Agent", "WorldWallpaper/2.0 (Android)")
        }
        try {
            if (c.responseCode !in 200..299) throw IOException("Server replied ${c.responseCode}")
            if (c.contentLengthLong > MAX_BYTES) throw IOException("File is too large")
            c.inputStream.use { input ->
                val out = ByteArrayOutputStream()
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    if (out.size() > MAX_BYTES) throw IOException("File is too large")
                }
                return out.toByteArray()
            }
        } finally {
            c.disconnect()
        }
    }

    fun getText(url: String): String = String(getBytes(url), Charsets.UTF_8)
}

/**
 * Bing publishes a new landscape photo every day, and each English edition often
 * has a different one. The archive endpoint gives about the last 15 days.
 */
object ImageSources {
    private val markets = listOf("en-US", "en-GB", "en-CA", "en-AU", "en-IN")

    /** Today's photo. Checked every interval; only applied when it changes. */
    fun bingDaily(): RemoteImage = list("en-IN", 0, 1).first()

    /** A random recent landscape from any edition, avoiding recently shown ones. */
    fun randomLandscape(recent: Set<String>): RemoteImage {
        val pool = (list(markets.random(), 0, 8) + list(markets.random(), 7, 8))
            .distinctBy { it.id }
        return pool.filter { it.id !in recent }.randomOrNull() ?: pool.random()
    }

    private fun list(market: String, daysAgo: Int, count: Int): List<RemoteImage> {
        val json = Http.getText(
            "https://www.bing.com/HPImageArchive.aspx?format=js&idx=$daysAgo&n=$count&mkt=$market"
        )
        val arr = JSONObject(json).getJSONArray("images")
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val base = o.getString("urlbase")       // /th?id=OHR.LakeTekapo_EN-US1234
            // The same photo has a different suffix per country, so dedupe on the name.
            val id = base.substringAfter("OHR.").substringBefore("_")
            val copyright = o.optString("copyright")  // "Place, Country (© Credit)"
            val place = copyright.substringBefore(" (©").trim()
            val credit = if ("(©" in copyright)
                "©" + copyright.substringAfter("(©").substringBeforeLast(")") else ""
            val title = o.optString("title").ifBlank { place }
            RemoteImage("https://www.bing.com${base}_UHD.jpg", id, title, place, credit.trim())
        }
    }
}
