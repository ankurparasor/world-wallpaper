# WorkManager and widget classes are kept by their own bundled rules.
