# World Wallpaper 2.0 (Android)

Downloads new landscape photos from around the world and sets them as your phone
wallpaper automatically, in the background. Includes a see-through home-screen
widget that shows where the current photo was taken.

## What's new in 2.0
- New design: full-screen photo header, cards, interval chips, live status, animations
- Home-screen widget: mostly transparent, shows the photo's title, place and credit, with a ↻ button
- Security:
  - encrypted (https) connections only, enforced app-wide
  - app data excluded from backups and phone-to-phone transfers
  - downloads capped at 25 MB, and oversized images refused
  - widget refresh button can't be triggered by other apps
  - release build: shrunk, not debuggable, signed with a fixed key so future builds install as updates

## Photo sources
- **World tour**: a different recent landscape each time (Bing's daily photos from 5 English editions, about 15 days each)
- **Photo of the day**: changes only when a new daily photo is published
- **My own link**: any https image link. The wallpaper changes whenever that image changes.

## Build
GitHub Actions builds `assembleRelease`. Download the **WorldWallpaper-apk** artifact.
In Android Studio: **Build → Generate Signed App Bundle / APK** isn't needed. Run `./gradlew assembleRelease`
and the APK is in `app/build/outputs/apk/release/`.

## Install (Galaxy S23)
1. **Uninstall version 1 first.** It used a different signing key, so 2.0 can't install over it.
2. Install the APK, open it, tap **New wallpaper**, then turn on **Change automatically**.
3. Tap **Background running** → Allow, then in **Settings → Apps → World Wallpaper → Battery**
   choose **Unrestricted**. Otherwise One UI may pause the updates.
4. Tap **Add home-screen widget** in the app (or long-press the home screen → Widgets).

## Notes
- `app/release.keystore` is the signing key. Keep your GitHub repository **private** so nobody
  else can sign apps as "World Wallpaper".
- Android runs background jobs at most every 15 minutes, and may delay them slightly in deep sleep.
- On mobile data, World tour every 30 min uses about 50–150 MB/day. Photo of the day downloads once a day.
- If Samsung's Dynamic Lock Screen or a Good Lock theme is on, it can override the lock-screen wallpaper.
